// Teams page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication status
    checkAuthStatus();
    
    // Setup event listeners
    setupTeamsEventListeners();
});

function setupTeamsEventListeners() {
    // Search Teammates button
    const searchTeammatesBtn = document.getElementById('search-teammates');
    if (searchTeammatesBtn) {
        searchTeammatesBtn.addEventListener('click', function() {
            const searchTerm = document.getElementById('teammate-search').value;
            searchTeammates(searchTerm);
        });
    }
    
    // Create Team button
    const createTeamBtn = document.getElementById('create-team');
    if (createTeamBtn) {
        createTeamBtn.addEventListener('click', function() {
            const currentUser = getCurrentUser();
            if (!currentUser) {
                alert('Please login to create a team');
                window.location.href = 'login.html';
            } else {
                const modal = new bootstrap.Modal(document.getElementById('createTeamModal'));
                modal.show();
            }
        });
    }
    
    // Save Team button
    const saveTeamBtn = document.getElementById('save-team');
    if (saveTeamBtn) {
        saveTeamBtn.addEventListener('click', function() {
            createNewTeam();
        });
    }
    
    // View Profile buttons
    const viewProfileButtons = document.querySelectorAll('.view-profile');
    viewProfileButtons.forEach(button => {
        button.addEventListener('click', function() {
            const userId = this.getAttribute('data-id');
            viewUserProfile(userId);
        });
    });
    
    // Invite to Team buttons
    const inviteButtons = document.querySelectorAll('.invite-to-team');
    inviteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const userId = this.getAttribute('data-id');
            inviteToTeam(userId);
        });
    });
    
    // Apply filters
    const roleFilter = document.getElementById('role-filter');
    const experienceFilter = document.getElementById('experience-filter');
    const hackathonFilter = document.getElementById('hackathon-filter');
    
    if (roleFilter) {
        roleFilter.addEventListener('change', applyTeammateFilters);
    }
    if (experienceFilter) {
        experienceFilter.addEventListener('change', applyTeammateFilters);
    }
    if (hackathonFilter) {
        hackathonFilter.addEventListener('change', applyTeammateFilters);
    }
}

function searchTeammates(searchTerm) {
    // In a real application, this would search a database
    // For now, we'll just show an alert
    if (searchTerm.trim() !== '') {
        alert(`Searching for teammates with skills: ${searchTerm}`);
        
        // Highlight matching skills in teammate cards
        const skillBadges = document.querySelectorAll('.skill-badge');
        skillBadges.forEach(badge => {
            if (badge.textContent.toLowerCase().includes(searchTerm.toLowerCase())) {
                badge.style.backgroundColor = 'var(--primary)';
                badge.style.color = 'white';
            }
        });
    }
}

function applyTeammateFilters() {
    const role = document.getElementById('role-filter').value;
    const experience = document.getElementById('experience-filter').value;
    const hackathon = document.getElementById('hackathon-filter').value;
    
    // In a real application, this would filter data from a server
    // For now, we'll just show an alert
    let filterMessage = 'Applying filters: ';
    if (role) filterMessage += `Role: ${role}, `;
    if (experience) filterMessage += `Experience: ${experience}, `;
    if (hackathon) filterMessage += `Hackathon: ${hackathon}`;
    
    console.log(filterMessage);
}

function createNewTeam() {
    const teamName = document.getElementById('team-name').value;
    const teamHackathon = document.getElementById('team-hackathon').value;
    const teamDescription = document.getElementById('team-description').value;
    
    if (!teamName || !teamHackathon) {
        alert('Please fill in all required fields');
        return;
    }
    
    const currentUser = getCurrentUser();
    const users = getUsers();
    const userIndex = users.findIndex(user => user.email === currentUser.email);
    
    if (userIndex !== -1) {
        // Initialize teams array if it doesn't exist
        if (!users[userIndex].teams) {
            users[userIndex].teams = [];
        }
        
        // Add team
        users[userIndex].teams.push({
            name: teamName,
            hackathonId: teamHackathon,
            description: teamDescription,
            members: [currentUser.email],
            createdAt: new Date().toISOString()
        });
        
        // Save updated users array
        saveUsers(users);
        
        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('createTeamModal'));
        modal.hide();
        
        // Reset form
        document.getElementById('create-team-form').reset();
        
        alert(`Team "${teamName}" created successfully!`);
    }
}

function viewUserProfile(userId) {
    // In a real application, this would redirect to the user's profile
    // For now, we'll just show an alert
    alert(`Viewing profile of user ${userId}`);
}

function inviteToTeam(userId) {
    const currentUser = getCurrentUser();
    if (!currentUser) {
        alert('Please login to invite teammates');
        window.location.href = 'login.html';
        return;
    }
    
    // In a real application, this would send an invitation
    // For now, we'll just show an alert
    alert(`Invitation sent to user ${userId}`);
    
    // Update button state
    const inviteButton = document.querySelector(`.invite-to-team[data-id="${userId}"]`);
    if (inviteButton) {
        inviteButton.textContent = 'Invitation Sent';
        inviteButton.disabled = true;
        inviteButton.classList.remove('btn-primary');
        inviteButton.classList.add('btn-secondary');
    }
}

// Get current user from localStorage (duplicate from auth.js for standalone functionality)
function getCurrentUser() {
    const userJSON = localStorage.getItem('hackhub_current_user');
    return userJSON ? JSON.parse(userJSON) : null;
}

// Get users from localStorage (duplicate from auth.js for standalone functionality)
function getUsers() {
    const usersJSON = localStorage.getItem('hackhub_users');
    return usersJSON ? JSON.parse(usersJSON) : [];
}

// Save users to localStorage (duplicate from auth.js for standalone functionality)
function saveUsers(users) {
    localStorage.setItem('hackhub_users', JSON.stringify(users));
}