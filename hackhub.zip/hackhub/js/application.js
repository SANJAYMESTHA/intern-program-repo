// Applications page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication status
    checkAuthStatus();
    
    // Load applications data
    loadApplications();
    
    // Setup event listeners
    setupApplicationsEventListeners();
});

function loadApplications() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const users = getUsers();
    const userData = users.find(user => user.email === currentUser.email);
    
    if (userData && userData.applications) {
        // This would typically load from a database
        // For now, we'll use mock data
        const hackathons = {
            '1': { name: 'Global AI Hackathon', date: 'Oct 15-17, 2023', status: 'Under Review' },
            '2': { name: 'Web3 Buildathon', date: 'Nov 5-7, 2023', status: 'Accepted' },
            '3': { name: 'FinTech Innovation Challenge', date: 'Dec 10-12, 2023', status: 'Registered' },
            '4': { name: 'ClimateTech Hackathon', date: 'Aug 12-14, 2023', status: 'Completed', result: '2nd Place' },
            '5': { name: 'Health & Wellness Hack', date: 'Jun 5-7, 2023', status: 'Completed', result: 'Participant' }
        };
        
        // You would implement logic here to display applications in the appropriate tabs
        console.log('User applications:', userData.applications);
    }
}

function setupApplicationsEventListeners() {
    // View Details buttons
    const viewDetailsButtons = document.querySelectorAll('.view-details');
    viewDetailsButtons.forEach(button => {
        button.addEventListener('click', function() {
            const hackathonId = this.getAttribute('data-id');
            showHackathonDetails(hackathonId);
        });
    });
    
    // Prepare Submission buttons
    const prepareSubmissionButtons = document.querySelectorAll('.btn-primary');
    prepareSubmissionButtons.forEach(button => {
        if (button.textContent.includes('Prepare Submission')) {
            button.addEventListener('click', function() {
                const currentUser = getCurrentUser();
                if (!currentUser) {
                    alert('Please login to prepare a submission');
                    window.location.href = 'login.html';
                } else {
                    alert('Redirecting to submission preparation page');
                    // In a real app, this would navigate to the submission page
                }
            });
        }
    });
    
    // Find Team buttons
    const findTeamButtons = document.querySelectorAll('.btn-primary');
    findTeamButtons.forEach(button => {
        if (button.textContent.includes('Find Team')) {
            button.addEventListener('click', function() {
                window.location.href = 'teams.html';
            });
        }
    });
    
    // Certificate buttons
    const certificateButtons = document.querySelectorAll('.btn-primary');
    certificateButtons.forEach(button => {
        if (button.textContent.includes('Certificate')) {
            button.addEventListener('click', function() {
                alert('Downloading certificate...');
                // In a real app, this would download a certificate
            });
        }
    });
    
    // View Project buttons
    const viewProjectButtons = document.querySelectorAll('.btn-outline-primary');
    viewProjectButtons.forEach(button => {
        if (button.textContent.includes('View Project')) {
            button.addEventListener('click', function() {
                alert('Opening project details...');
                // In a real app, this would show project details
            });
        }
    });
}

// Show hackathon details in modal (duplicate from main.js for standalone functionality)
function showHackathonDetails(hackathonId) {
    const hackathons = {
        '1': {
            title: 'Global AI Hackathon',
            image: 'https://images.unsplash.com/photo-1535223289827-42f1e9919769?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Oct 15-17, 2023',
            description: 'Join the largest AI hackathon with $100K in prizes. This event brings together the brightest minds in artificial intelligence to solve real-world problems.',
            location: 'Online',
            prizes: '$100,000',
            themes: 'AI/ML, Machine Learning, Deep Learning, NLP',
            eligibility: 'Open to all students and professionals',
            registration: 'Free',
            website: 'https://example.com'
        },
        '2': {
            title: 'Web3 Buildathon',
            image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Nov 5-7, 2023',
            description: 'Build the future of decentralized web applications. This hackathon focuses on blockchain technology and decentralized applications.',
            location: 'Hybrid (Online & San Francisco)',
            prizes: '$75,000',
            themes: 'Blockchain, Web3, Smart Contracts, DeFi',
            eligibility: 'Developers, designers, and blockchain enthusiasts',
            registration: 'Free',
            website: 'https://example.com'
        },
        '3': {
            title: 'FinTech Innovation Challenge',
            image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Dec 10-12, 2023',
            description: 'Revolutionize the financial technology industry. Create innovative solutions for banking, payments, investments, and more.',
            location: 'On-site (New York)',
            prizes: '$50,000',
            themes: 'FinTech, Banking, Payments, Blockchain',
            eligibility: 'Students and professionals in finance and technology',
            registration: 'Free',
            website: 'https://example.com'
        },
        '4': {
            title: 'ClimateTech Hackathon',
            image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Oct 20-22, 2023',
            description: 'Develop solutions to combat climate change. This hackathon focuses on sustainability and environmental technology.',
            location: 'On-site',
            prizes: '$75,000',
            themes: 'Sustainability, Clean Energy, Carbon Reduction',
            eligibility: 'Open to all',
            registration: 'Free',
            website: 'https://example.com'
        },
        '5': {
            title: 'Health & Wellness Hack',
            image: 'https://images.unsplash.com/photo-1543286386-713bdd548da4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Nov 12-14, 2023',
            description: 'Innovate solutions for better health outcomes. Focus on healthcare technology, wellness apps, and medical devices.',
            location: 'Online',
            prizes: '$60,000',
            themes: 'Healthcare, Wellness, Medical Technology',
            eligibility: 'Healthcare professionals, developers, and designers',
            registration: 'Free',
            website: 'https://example.com'
        }
    };
    
    const hackathon = hackathons[hackathonId];
    if (hackathon) {
        document.getElementById('modalHackathonTitle').textContent = hackathon.title;
        
        const modalBody = document.getElementById('modalHackathonBody');
        modalBody.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <img src="${hackathon.image}" class="img-fluid rounded mb-3" alt="${hackathon.title}">
                    <p><strong>Date:</strong> ${hackathon.date}</p>
                    <p><strong>Location:</strong> ${hackathon.location}</p>
                    <p><strong>Prize Pool:</strong> ${hackathon.prizes}</p>
                    <p><strong>Registration:</strong> ${hackathon.registration}</p>
                </div>
                <div class="col-md-6">
                    <h5>Description</h5>
                    <p>${hackathon.description}</p>
                    
                    <h5>Themes</h5>
                    <p>${hackathon.themes}</p>
                    
                    <h5>Eligibility</h5>
                    <p>${hackathon.eligibility}</p>
                    
                    <a href="${hackathon.website}" target="_blank" class="btn btn-outline-primary">Official Website</a>
                </div>
            </div>
        `;
        
        const modal = new bootstrap.Modal(document.getElementById('hackathonDetailsModal'));
        modal.show();
    }
}

// Get current user from localStorage (duplicate from auth.js for standalone functionality)
function getCurrentUser() {
    const userJSON = localStorage.getItem('hackhub_current_user');
    return userJSON ? JSON.parse(userJSON) : null;
}

// Get users from localStorage (duplicate from auth.js for standalone functionality)
function getUsers() {
    const usersJSON = localStorage.getItem('hackhub_users');
    return usersJSON ? JSON.parse(usersJSON) : [];
}