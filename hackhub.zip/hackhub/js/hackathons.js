// Hackathons page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication status
    checkAuthStatus();
    
    // Load hackathons data
    loadHackathons();
    
    // Setup event listeners
    setupHackathonsEventListeners();
});

function loadHackathons() {
    // Check if there's a search term from the homepage
    const searchTerm = localStorage.getItem('hackhub_search_term');
    if (searchTerm) {
        document.getElementById('global-search').value = searchTerm;
        // Clear the search term after using it
        localStorage.removeItem('hackhub_search_term');
        
        // Filter hackathons based on search term
        filterHackathons(searchTerm);
    }
}

function setupHackathonsEventListeners() {
    // Apply Filters button
    const applyFiltersBtn = document.getElementById('apply-filters');
    if (applyFiltersBtn) {
        applyFiltersBtn.addEventListener('click', function() {
            applyFilters();
        });
    }
    
    // Search functionality
    const searchButton = document.getElementById('search-button');
    if (searchButton) {
        searchButton.addEventListener('click', function() {
            const searchTerm = document.getElementById('global-search').value;
            filterHackathons(searchTerm);
        });
    }
    
    // View Details buttons
    const viewDetailsButtons = document.querySelectorAll('.view-details');
    viewDetailsButtons.forEach(button => {
        button.addEventListener('click', function() {
            const hackathonId = this.getAttribute('data-id');
            showHackathonDetails(hackathonId);
        });
    });
    
    // Apply Now buttons
    const applyButtons = document.querySelectorAll('.apply-now');
    applyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const currentUser = getCurrentUser();
            if (!currentUser) {
                alert('Please login to apply for hackathons');
                window.location.href = 'login.html';
            } else {
                const hackathonId = this.getAttribute('data-id');
                applyForHackathon(hackathonId);
            }
        });
    });
    
    // Modal Apply button
    const modalApplyButton = document.getElementById('modalApplyButton');
    if (modalApplyButton) {
        modalApplyButton.addEventListener('click', function() {
            const currentUser = getCurrentUser();
            if (!currentUser) {
                alert('Please login to apply for hackathons');
                window.location.href = 'login.html';
            } else {
                const hackathonId = modalApplyButton.getAttribute('data-id');
                applyForHackathon(hackathonId);
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('hackathonDetailsModal'));
                modal.hide();
            }
        });
    }
}

function applyFilters() {
    const category = document.getElementById('category-filter').value;
    const location = document.getElementById('location-filter').value;
    const status = document.getElementById('status-filter').value;
    
    // In a real application, this would filter data from a server
    // For now, we'll just show an alert
    let filterMessage = 'Applying filters: ';
    if (category) filterMessage += `Category: ${category}, `;
    if (location) filterMessage += `Location: ${location}, `;
    if (status) filterMessage += `Status: ${status}`;
    
    alert(filterMessage);
}

function filterHackathons(searchTerm) {
    // In a real application, this would filter data from a server
    // For now, we'll just show an alert
    alert(`Filtering hackathons by: ${searchTerm}`);
    
    // Highlight the search term in hackathon cards
    const hackathonCards = document.querySelectorAll('.hackathon-card');
    hackathonCards.forEach(card => {
        const text = card.textContent.toLowerCase();
        if (text.includes(searchTerm.toLowerCase())) {
            card.style.boxShadow = '0 0 15px rgba(74, 0, 224, 0.3)';
            card.style.transition = 'box-shadow 0.3s ease';
        } else {
            card.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.05)';
        }
    });
}

// Show hackathon details in modal
function showHackathonDetails(hackathonId) {
    const hackathons = {
        '1': {
            title: 'Global AI Hackathon',
            image: 'https://images.unsplash.com/photo-1535223289827-42f1e9919769?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Oct 15-17, 2023',
            description: 'Join the largest AI hackathon with $100K in prizes. This event brings together the brightest minds in artificial intelligence to solve real-world problems.',
            location: 'Online',
            prizes: '$100,000',
            themes: 'AI/ML, Machine Learning, Deep Learning, NLP',
            eligibility: 'Open to all students and professionals',
            registration: 'Free',
            website: 'https://example.com'
        },
        '2': {
            title: 'Web3 Buildathon',
            image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Nov 5-7, 2023',
            description: 'Build the future of decentralized web applications. This hackathon focuses on blockchain technology and decentralized applications.',
            location: 'Hybrid (Online & San Francisco)',
            prizes: '$75,000',
            themes: 'Blockchain, Web3, Smart Contracts, DeFi',
            eligibility: 'Developers, designers, and blockchain enthusiasts',
            registration: 'Free',
            website: 'https://example.com'
        },
        '3': {
            title: 'FinTech Innovation Challenge',
            image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Dec 10-12, 2023',
            description: 'Revolutionize the financial technology industry. Create innovative solutions for banking, payments, investments, and more.',
            location: 'On-site (New York)',
            prizes: '$50,000',
            themes: 'FinTech, Banking, Payments, Blockchain',
            eligibility: 'Students and professionals in finance and technology',
            registration: 'Free',
            website: 'https://example.com'
        },
        '4': {
            title: 'ClimateTech Hackathon',
            image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Oct 20-22, 2023',
            description: 'Develop solutions to combat climate change. This hackathon focuses on sustainability and environmental technology.',
            location: 'On-site',
            prizes: '$75,000',
            themes: 'Sustainability, Clean Energy, Carbon Reduction',
            eligibility: 'Open to all',
            registration: 'Free',
            website: 'https://example.com'
        },
        '5': {
            title: 'Health & Wellness Hack',
            image: 'https://images.unsplash.com/photo-1543286386-713bdd548da4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Nov 12-14, 2023',
            description: 'Innovate solutions for better health outcomes. Focus on healthcare technology, wellness apps, and medical devices.',
            location: 'Online',
            prizes: '$60,000',
            themes: 'Healthcare, Wellness, Medical Technology',
            eligibility: 'Healthcare professionals, developers, and designers',
            registration: 'Free',
            website: 'https://example.com'
        },
        '6': {
            title: 'EdTech Innovation Challenge',
            image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Dec 1-3, 2023',
            description: 'Transform the future of education technology. Create innovative learning platforms, tools, and experiences.',
            location: 'Hybrid',
            prizes: '$45,000',
            themes: 'Education, E-learning, EdTech',
            eligibility: 'Educators, students, and developers',
            registration: 'Free',
            website: 'https://example.com'
        }
    };
    
    const hackathon = hackathons[hackathonId];
    if (hackathon) {
        document.getElementById('modalHackathonTitle').textContent = hackathon.title;
        document.getElementById('modalApplyButton').setAttribute('data-id', hackathonId);
        
        const modalBody = document.getElementById('modalHackathonBody');
        modalBody.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <img src="${hackathon.image}" class="img-fluid rounded mb-3" alt="${hackathon.title}">
                    <p><strong>Date:</strong> ${hackathon.date}</p>
                    <p><strong>Location:</strong> ${hackathon.location}</p>
                    <p><strong>Prize Pool:</strong> ${hackathon.prizes}</p>
                    <p><strong>Registration:</strong> ${hackathon.registration}</p>
                </div>
                <div class="col-md-6">
                    <h5>Description</h5>
                    <p>${hackathon.description}</p>
                    
                    <h5>Themes</h5>
                    <p>${hackathon.themes}</p>
                    
                    <h5>Eligibility</h5>
                    <p>${hackathon.eligibility}</p>
                    
                    <a href="${hackathon.website}" target="_blank" class="btn btn-outline-primary">Official Website</a>
                </div>
            </div>
        `;
        
        const modal = new bootstrap.Modal(document.getElementById('hackathonDetailsModal'));
        modal.show();
    }
}

// Apply for a hackathon
function applyForHackathon(hackathonId) {
    const currentUser = getCurrentUser();
    const users = getUsers();
    const userIndex = users.findIndex(user => user.email === currentUser.email);
    
    if (userIndex !== -1) {
        // Initialize applications array if it doesn't exist
        if (!users[userIndex].applications) {
            users[userIndex].applications = [];
        }
        
        // Check if user has already applied
        const existingApplication = users[userIndex].applications.find(app => app.hackathonId === hackathonId);
        if (existingApplication) {
            alert('You have already applied for this hackathon!');
            return;
        }
        
        // Add application
        users[userIndex].applications.push({
            hackathonId: hackathonId,
            appliedAt: new Date().toISOString(),
            status: 'pending'
        });
        
        // Save updated users array
        saveUsers(users);
        
        alert('Application submitted successfully!');
    }
}

// Get current user from localStorage
function getCurrentUser() {
    const userJSON = localStorage.getItem('hackhub_current_user');
    return userJSON ? JSON.parse(userJSON) : null;
}

// Get users from localStorage
function getUsers() {
    const usersJSON = localStorage.getItem('hackhub_users');
    return usersJSON ? JSON.parse(usersJSON) : [];
}

// Save users to localStorage
function saveUsers(users) {
    localStorage.setItem('hackhub_users', JSON.stringify(users));
}