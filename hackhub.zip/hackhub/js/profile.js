// Profile page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication status
    checkAuthStatus();
    
    // Load user profile data
    loadProfileData();
    
    // Setup event listeners
    setupProfileEventListeners();
});

function loadProfileData() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const users = getUsers();
    const userData = users.find(user => user.email === currentUser.email);
    
    if (userData) {
        // Update profile information
        document.getElementById('profile-name').textContent = userData.name;
        document.getElementById('profile-title').textContent = userData.profile.title;
        document.getElementById('profile-bio').textContent = userData.profile.bio;
        document.getElementById('profile-email').textContent = userData.email;
        document.getElementById('profile-location').textContent = userData.profile.location;
        document.getElementById('profile-phone').textContent = userData.profile.phone;
        document.getElementById('about-text').textContent = userData.profile.about;
        
        // Populate edit form
        const nameParts = userData.name.split(' ');
        document.getElementById('edit-first-name').value = nameParts[0] || '';
        document.getElementById('edit-last-name').value = nameParts.slice(1).join(' ') || '';
        document.getElementById('edit-title').value = userData.profile.title;
        document.getElementById('edit-bio').value = userData.profile.bio;
        document.getElementById('edit-location').value = userData.profile.location;
        document.getElementById('edit-phone').value = userData.profile.phone;
        document.getElementById('edit-about').value = userData.profile.about;
        
        // Load skills
        const skillsContainer = document.getElementById('skills-container');
        if (skillsContainer) {
            skillsContainer.innerHTML = '';
            userData.profile.skills.forEach(skill => {
                const skillBadge = document.createElement('span');
                skillBadge.className = 'skill-badge';
                skillBadge.textContent = skill;
                skillsContainer.appendChild(skillBadge);
            });
        }
        
        // Load applications if they exist
        if (userData.applications) {
            loadApplications(userData.applications);
        }
    }
}

function loadApplications(applications) {
    // This would typically load from a database
    // For now, we'll use mock data
    const hackathons = {
        '1': { name: 'Global AI Hackathon', date: 'Oct 15-17, 2023', status: 'Under Review' },
        '2': { name: 'Web3 Buildathon', date: 'Nov 5-7, 2023', status: 'Accepted' },
        '3': { name: 'FinTech Innovation Challenge', date: 'Dec 10-12, 2023', status: 'Upcoming' },
        '4': { name: 'ClimateTech Hackathon', date: 'Aug 12-14, 2023', status: 'Completed', result: '2nd Place' },
        '5': { name: 'Health & Wellness Hack', date: 'Jun 5-7, 2023', status: 'Completed', result: 'Participant' }
    };
    
    // Update applications tab content
    const ongoingTab = document.getElementById('ongoing');
    const upcomingTab = document.getElementById('upcoming');
    const pastTab = document.getElementById('past');
    
    if (ongoingTab) {
        ongoingTab.innerHTML = '';
        applications.filter(app => app.status === 'pending' || app.status === 'accepted').forEach(app => {
            if (hackathons[app.hackathonId]) {
                const hackathon = hackathons[app.hackathonId];
                const statusClass = app.status === 'accepted' ? 'bg-success' : 'bg-warning text-dark';
                
                ongoingTab.innerHTML += `
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h6>${hackathon.name}</h6>
                                    <p class="text-muted mb-0">Applied on: ${formatDate(app.appliedAt)}</p>
                                </div>
                                <span class="badge ${statusClass}">${hackathon.status}</span>
                            </div>
                        </div>
                    </div>
                `;
            }
        });
        
        if (ongoingTab.innerHTML === '') {
            ongoingTab.innerHTML = '<p class="text-muted">No ongoing applications.</p>';
        }
    }
}

function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

function setupProfileEventListeners() {
    // Save profile button
    const saveProfileBtn = document.getElementById('save-profile');
    if (saveProfileBtn) {
        saveProfileBtn.addEventListener('click', function() {
            saveProfileChanges();
        });
    }
    
    // View Details buttons in applications tab
    const viewDetailsButtons = document.querySelectorAll('.view-details');
    viewDetailsButtons.forEach(button => {
        button.addEventListener('click', function() {
            const hackathonId = this.getAttribute('data-id');
            showHackathonDetails(hackathonId);
        });
    });
}

function saveProfileChanges() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const users = getUsers();
    const userIndex = users.findIndex(user => user.email === currentUser.email);
    
    if (userIndex !== -1) {
        // Update user data
        users[userIndex].name = `${document.getElementById('edit-first-name').value} ${document.getElementById('edit-last-name').value}`;
        users[userIndex].profile.title = document.getElementById('edit-title').value;
        users[userIndex].profile.bio = document.getElementById('edit-bio').value;
        users[userIndex].profile.location = document.getElementById('edit-location').value;
        users[userIndex].profile.phone = document.getElementById('edit-phone').value;
        users[userIndex].profile.about = document.getElementById('edit-about').value;
        
        // Save updated users array
        saveUsers(users);
        
        // Update current user name
        const updatedUser = {
            name: users[userIndex].name,
            email: currentUser.email
        };
        localStorage.setItem('hackhub_current_user', JSON.stringify(updatedUser));
        
        // Reload profile data
        loadProfileData();
        
        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('editProfileModal'));
        modal.hide();
        
        // Show success message
        alert('Profile updated successfully!');
    }
}

// Show hackathon details in modal
function showHackathonDetails(hackathonId) {
    const hackathons = {
        '1': {
            title: 'Global AI Hackathon',
            image: 'https://images.unsplash.com/photo-1535223289827-42f1e9919769?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Oct 15-17, 2023',
            description: 'Join the largest AI hackathon with $100K in prizes. This event brings together the brightest minds in artificial intelligence to solve real-world problems.',
            location: 'Online',
            prizes: '$100,000',
            themes: 'AI/ML, Machine Learning, Deep Learning, NLP',
            eligibility: 'Open to all students and professionals',
            registration: 'Free',
            website: 'https://example.com'
        },
        '2': {
            title: 'Web3 Buildathon',
            image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Nov 5-7, 2023',
            description: 'Build the future of decentralized web applications. This hackathon focuses on blockchain technology and decentralized applications.',
            location: 'Hybrid (Online & San Francisco)',
            prizes: '$75,000',
            themes: 'Blockchain, Web3, Smart Contracts, DeFi',
            eligibility: 'Developers, designers, and blockchain enthusiasts',
            registration: 'Free',
            website: 'https://example.com'
        },
        '3': {
            title: 'FinTech Innovation Challenge',
            image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Dec 10-12, 2023',
            description: 'Revolutionize the financial technology industry. Create innovative solutions for banking, payments, investments, and more.',
            location: 'On-site (New York)',
            prizes: '$50,000',
            themes: 'FinTech, Banking, Payments, Blockchain',
            eligibility: 'Students and professionals in finance and technology',
            registration: 'Free',
            website: 'https://example.com'
        },
        '4': {
            title: 'ClimateTech Hackathon',
            image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Oct 20-22, 2023',
            description: 'Develop solutions to combat climate change. This hackathon focuses on sustainability and environmental technology.',
            location: 'On-site',
            prizes: '$75,000',
            themes: 'Sustainability, Clean Energy, Carbon Reduction',
            eligibility: 'Open to all',
            registration: 'Free',
            website: 'https://example.com'
        },
        '5': {
            title: 'Health & Wellness Hack',
            image: 'https://images.unsplash.com/photo-1543286386-713bdd548da4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
            date: 'Nov 12-14, 2023',
            description: 'Innovate solutions for better health outcomes. Focus on healthcare technology, wellness apps, and medical devices.',
            location: 'Online',
            prizes: '$60,000',
            themes: 'Healthcare, Wellness, Medical Technology',
            eligibility: 'Healthcare professionals, developers, and designers',
            registration: 'Free',
            website: 'https://example.com'
        }
    };
    
    const hackathon = hackathons[hackathonId];
    if (hackathon) {
        document.getElementById('modalHackathonTitle').textContent = hackathon.title;
        
        const modalBody = document.getElementById('modalHackathonBody');
        modalBody.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <img src="${hackathon.image}" class="img-fluid rounded mb-3" alt="${hackathon.title}">
                    <p><strong>Date:</strong> ${hackathon.date}</p>
                    <p><strong>Location:</strong> ${hackathon.location}</p>
                    <p><strong>Prize Pool:</strong> ${hackathon.prizes}</p>
                    <p><strong>Registration:</strong> ${hackathon.registration}</p>
                </div>
                <div class="col-md-6">
                    <h5>Description</h5>
                    <p>${hackathon.description}</p>
                    
                    <h5>Themes</h5>
                    <p>${hackathon.themes}</p>
                    
                    <h5>Eligibility</h5>
                    <p>${hackathon.eligibility}</p>
                    
                    <a href="${hackathon.website}" target="_blank" class="btn btn-outline-primary">Official Website</a>
                </div>
            </div>
        `;
        
        const modal = new bootstrap.Modal(document.getElementById('hackathonDetailsModal'));
        modal.show();
    }
}

// Get current user from localStorage
function getCurrentUser() {
    const userJSON = localStorage.getItem('hackhub_current_user');
    return userJSON ? JSON.parse(userJSON) : null;
}

// Get users from localStorage
function getUsers() {
    const usersJSON = localStorage.getItem('hackhub_users');
    return usersJSON ? JSON.parse(usersJSON) : [];
}

// Save users to localStorage
function saveUsers(users) {
    localStorage.setItem('hackhub_users', JSON.stringify(users));
}