// Authentication functionality
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    checkAuthStatus();
    
    // Setup authentication forms if they exist on this page
    if (document.getElementById('login-form') || document.getElementById('register-form')) {
        setupAuthForms();
    }
    
    // Setup logout button if it exists
    if (document.getElementById('logout-btn')) {
        document.getElementById('logout-btn').addEventListener('click', function(e) {
            e.preventDefault();
            logout();
        });
    }
});

// Check authentication status and update UI
function checkAuthStatus() {
    const currentUser = getCurrentUser();
    const authButtons = document.getElementById('auth-buttons');
    const userMenu = document.getElementById('user-menu');
    const usernameDisplay = document.getElementById('username-display');
    
    if (currentUser) {
        // User is logged in
        if (authButtons) authButtons.style.display = 'none';
        if (userMenu) userMenu.style.display = 'flex';
        if (usernameDisplay) usernameDisplay.textContent = currentUser.name;
    } else {
        // User is not logged in
        if (authButtons) authButtons.style.display = 'flex';
        if (userMenu) userMenu.style.display = 'none';
        
        // If on profile page or applications page, redirect to login
        if (window.location.pathname.endsWith('profile.html') || 
            window.location.pathname.endsWith('applications.html')) {
            window.location.href = 'login.html';
        }
    }
}

// Get current user from localStorage
function getCurrentUser() {
    const userJSON = localStorage.getItem('hackhub_current_user');
    return userJSON ? JSON.parse(userJSON) : null;
}

// Setup authentication forms
function setupAuthForms() {
    // DOM Elements
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const successAlert = document.getElementById('success-alert');
    const errorAlert = document.getElementById('error-alert');
    
    // Password toggle functionality
    if (document.getElementById('login-password-toggle')) {
        setupPasswordToggle('login-password-toggle', 'login-password');
    }
    
    if (document.getElementById('register-password-toggle')) {
        setupPasswordToggle('register-password-toggle', 'register-password');
        setupPasswordToggle('register-confirm-password-toggle', 'register-confirm-password');
    }
    
    // Form submissions
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            
            if (authenticateUser(email, password)) {
                showAlert(successAlert, 'Login successful! Redirecting...');
                // Redirect to homepage after successful login
                setTimeout(function() {
                    window.location.href = 'index.html';
                }, 1000);
            } else {
                showAlert(errorAlert, 'Invalid email or password');
            }
        });
    }
    
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('register-name').value;
            const email = document.getElementById('register-email').value;
            const password = document.getElementById('register-password').value;
            const confirmPassword = document.getElementById('register-confirm-password').value;
            
            // Validate passwords match
            if (password !== confirmPassword) {
                showAlert(errorAlert, 'Passwords do not match');
                return;
            }
            
            // Validate password length
            if (password.length < 8) {
                showAlert(errorAlert, 'Password must be at least 8 characters');
                return;
            }
            
            if (registerUser(name, email, password)) {
                showAlert(successAlert, 'Registration successful! You can now login.');
                // Clear form
                registerForm.reset();
                // Redirect to login after a delay
                setTimeout(function() {
                    window.location.href = 'login.html';
                }, 1500);
            } else {
                showAlert(errorAlert, 'Email already registered');
            }
        });
    }
}

// User management functions
function getUsers() {
    const usersJSON = localStorage.getItem('hackhub_users');
    return usersJSON ? JSON.parse(usersJSON) : [];
}

function saveUsers(users) {
    localStorage.setItem('hackhub_users', JSON.stringify(users));
}

function registerUser(name, email, password) {
    const users = getUsers();
    
    // Check if user already exists
    if (users.some(user => user.email === email)) {
        return false;
    }
    
    // Add new user
    users.push({
        name,
        email,
        password, // In a real app, this would be hashed
        createdAt: new Date().toISOString(),
        profile: {
            title: 'Developer',
            bio: 'A passionate hackathon participant',
            location: '',
            phone: '',
            skills: ['JavaScript', 'HTML', 'CSS'],
            about: 'I love participating in hackathons and building innovative solutions.'
        }
    });
    
    saveUsers(users);
    return true;
}

function authenticateUser(email, password) {
    const users = getUsers();
    const user = users.find(user => user.email === email && user.password === password);
    
    if (user) {
        // Set current user in localStorage
        localStorage.setItem('hackhub_current_user', JSON.stringify({
            name: user.name,
            email: user.email,
            profile: user.profile
        }));
        return true;
    }
    
    return false;
}

function logout() {
    localStorage.removeItem('hackhub_current_user');
    window.location.href = 'index.html';
}

// Helper functions
function setupPasswordToggle(toggleId, inputId) {
    const toggle = document.getElementById(toggleId);
    const input = document.getElementById(inputId);
    
    if (toggle && input) {
        toggle.addEventListener('click', function() {
            if (input.type === 'password') {
                input.type = 'text';
                toggle.innerHTML = '<i class="fas fa-eye-slash"></i>';
            } else {
                input.type = 'password';
                toggle.innerHTML = '<i class="fas fa-eye"></i>';
            }
        });
    }
}

function showAlert(alertElement, message) {
    if (!alertElement) return;
    
    alertElement.textContent = message;
    alertElement.style.display = 'block';
    
    // Hide alert after 3 seconds
    setTimeout(function() {
        alertElement.style.display = 'none';
    }, 3000);
}