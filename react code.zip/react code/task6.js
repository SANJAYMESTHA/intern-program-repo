import React, { useState } from 'react';
import './App.css'; // optional styling

function Counter() {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(prev => prev + 1);
  };

  const decrement = () => {
    setCount(prev => prev - 1);
  };

  return (
    <div className="counter-container">
      <h2>Counter: {count}</h2>
      <button onClick={decrement}>-</button>
      <button onClick={increment}>+</button>
    </div>
  );
}

function App() {
  return (
    <div className="App">
      <h1>Simple Counter App</h1>
      <Counter />
    </div>
  );
}

export default App;
