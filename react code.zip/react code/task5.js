import React, { useState } from 'react';
import './App.css';

function App() {
  const [isOn, setIsOn] = useState(false); // initial state is OFF

  const toggleSwitch = () => {
    setIsOn(prevState => !prevState);
  };

  return (
    <div className="App">
      <h1>Toggle Component</h1>
      <button onClick={toggleSwitch}>
        {isOn ? 'Turn OFF' : 'Turn ON'}
      </button>
      <p>Status: <strong>{isOn ? 'ON' : 'OFF'}</strong></p>
    </div>
  );
}

export default App;
