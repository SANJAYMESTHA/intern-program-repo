import React from 'react';

// ListItems component
function ListItems(props) {
  return (
    <ul>
      {props.items.map((item, index) => (
        <li key={index}>{item}</li>
      ))}
    </ul>
  );
}

// App component
function App() {
  const fruits = ['Apple', 'Banana', 'Cherry'];

  return (
    <div>
      <h1>Fruit List</h1>
      <ListItems items={fruits} />
    </div>
  );
}

export default App;
