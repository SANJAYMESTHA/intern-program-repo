import React from 'react';
import Product from './Product';
import './App.css';

function App() {
  const sampleProduct = {
    id: 1,
    name: "Wireless Headphones",
    price: 1999,
    description: "High-quality over-ear wireless headphones with noise cancellation."
  };

  return (
    <div className="App">
      <h1>Product Store</h1>
      <Product product={sampleProduct} />
    </div>
  );
}

export default App;
