import React from 'react';
import './App.css';

// StatusIndicator component
function StatusIndicator({ isOnline }) {
  const circleStyle = {
    width: '20px',
    height: '20px',
    borderRadius: '50%',
    backgroundColor: isOnline ? 'green' : 'red',
    display: 'inline-block',
    marginRight: '10px'
  };

  return (
    <div>
      <span style={circleStyle}></span>
      {isOnline ? 'Online' : 'Offline'}
    </div>
  );
}

// App component
function App() {
  return (
    <div className="App">
      <h1>User Status</h1>
      <StatusIndicator isOnline={true} />
      <StatusIndicator isOnline={false} />
    </div>
  );
}

export default App;
