import React, { useState } from 'react';
import './App.css';

// ProductsList component
function ProductsList({ products }) {
  return (
    <div>
      <h2>Products</h2>
      {products.map(product => (
        <div key={product.id} className="product-item">
          <strong>ID:</strong> {product.id} <br />
          <strong>Name:</strong> {product.name}
        </div>
      ))}
    </div>
  );
}

// App component
function App() {
  const [products, setProducts] = useState([
    { id: 1, name: 'Laptop' },
    { id: 2, name: 'Phone' }
  ]);

  const [newProduct, setNewProduct] = useState({ id: '', name: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewProduct(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const addProduct = () => {
    const { id, name } = newProduct;

    if (id.trim() === '' || name.trim() === '') {
      alert('Please enter both Product ID and Name.');
      return;
    }

    if (products.some(p => p.id.toString() === id.trim())) {
      alert('Product ID must be unique.');
      return;
    }

    const newEntry = { id: parseInt(id), name };
    setProducts([...products, newEntry]);
    setNewProduct({ id: '', name: '' }); // Reset input
  };

  return (
    <div className="App">
      <h1>Product List App</h1>

      <div className="form-group">
        <input
          type="text"
          name="id"
          placeholder="Enter Product ID"
          value={newProduct.id}
          onChange={handleChange}
        />
        <input
          type="text"
          name="name"
          placeholder="Enter Product Name"
          value={newProduct.name}
          onChange={handleChange}
        />
        <button onClick={addProduct}>Add Product</button>
      </div>

      <ProductsList products={products} />
    </div>
  );
}

export default App;
