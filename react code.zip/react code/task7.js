import React from 'react';
import './App.css'; // for styling

// Card component using children
function Card({ children }) {
  return (
    <div className="card">
      {children}
    </div>
  );
}


function App() {
  return (
    <div className="App">
      <h1>Card Example</h1>

      <Card>
        <h2>Title Inside Card</h2>
        <p>This is some content inside the card.</p>
        <button>Click Me</button>
      </Card>
    </div>
  );
}

export default App;
