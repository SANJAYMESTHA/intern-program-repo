import React from 'react';
import './App.css'; // for optional styling

// ProfileCard component
function ProfileCard({ name, email, avatarUrl }) {
  return (
    <div className="card">
      <img src={avatarUrl} alt={${name}'s avatar} className="avatar" />
      <h2>{name}</h2>
      <p>{email}</p>
    </div>
  );
}

// App component
function App() {
  return (
    <div className="App">
      <h1>User Profile</h1>
      <ProfileCard
        name="Alice Johnson"
        email="alice@example.com"
        avatarUrl="https://i.pravatar.cc/150?img=1"
      />
    </div>
  );
}

export default App;
