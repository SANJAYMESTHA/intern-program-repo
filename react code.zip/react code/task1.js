import React from "react";

// Welcome component
function Welcome(props) {
  return <h2>Hello, {props.name}!</h2>;
}

// App component
function App() {
  return (
    <div>
      <Welcome name="Alice" />
      <Welcome name="Bob" />
      <Welcome name="Charlie" />
    </div>
  );
}

export default App;