import React, { useState } from 'react';
import './App.css';

function App() {
  const [activeTab, setActiveTab] = useState('Home');

  // Content for each tab
  const renderContent = () => {
    switch (activeTab) {
      case 'Home':
        return <p>Welcome to the Home page!</p>;
      case 'About':
        return <p>This is the About section with information about us.</p>;
      case 'Contact':
        return <p>You can contact us at contact@example.com.</p>;
      default:
        return null;
    }
  };

  return (
    <div className="App">
      <h1>Dynamic Tabs Example</h1>
      
      <div className="tabs">
        <button
          className={activeTab === 'Home' ? 'active' : ''}
          onClick={() => setActiveTab('Home')}
        >
          Home
        </button>
        <button
          className={activeTab === 'About' ? 'active' : ''}
          onClick={() => setActiveTab('About')}
        >
          About
        </button>
        <button
          className={activeTab === 'Contact' ? 'active' : ''}
          onClick={() => setActiveTab('Contact')}
        >
          Contact
        </button>
      </div>

      <div className="tab-content">
        {renderContent()}
      </div>
    </div>
  );
}

export default App;
