import React from 'react';
import './App.css';

// ClickLogger component
function ClickLogger({ logMessage }) {
  return (
    <button onClick={logMessage}>Click to Log</button>
  );
}

// App component
function App() {
  const logMessage = () => {
    console.log('Button in ClickLogger was clicked!');
  };

  return (
    <div className="App">
      <h1>Function as Prop Example</h1>
      <ClickLogger logMessage={logMessage} />
    </div>
  );
}

export default App;
