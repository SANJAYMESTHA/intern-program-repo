import React, { useState } from 'react';
import './App.css';

function App() {
  const questions = [
    {
      question: "What is the capital of France?",
      options: ["Paris", "Rome", "Berlin", "Madrid"],
      answer: "Paris"
    },
    {
      question: "What is 2 + 2?",
      options: ["3", "4", "5", "6"],
      answer: "4"
    },
    {
      question: "Which language is used for web development?",
      options: ["Python", "Java", "HTML", "C++"],
      answer: "HTML"
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState('');
  const [showResult, setShowResult] = useState(false);

  const currentQuestion = questions[currentIndex];

  const handleOptionClick = (option) => {
    setSelectedOption(option);
    setShowResult(true);
  };

  const goToNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedOption('');
      setShowResult(false);
    }
  };

  const goToPrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setSelectedOption('');
      setShowResult(false);
    }
  };

  return (
    <div className="App">
      <h1>Quiz App</h1>

      <div className="quiz-card">
        <h2>Q{currentIndex + 1}: {currentQuestion.question}</h2>

        <ul>
          {currentQuestion.options.map((opt, idx) => (
            <li
              key={idx}
              onClick={() => handleOptionClick(opt)}
              className={option ${selectedOption === opt ? 'selected' : ''}}
            >
              {opt}
            </li>
          ))}
        </ul>

        {showResult && (
          <div className={result ${selectedOption === currentQuestion.answer ? 'correct' : 'wrong'}}>
            {selectedOption === currentQuestion.answer ? '✅ Correct!' : ❌ Wrong. Correct answer: ${currentQuestion.answer}}
          </div>
        )}

        <div className="nav-buttons">
          <button onClick={goToPrevious} disabled={currentIndex === 0}>
            Previous
          </button>
          <button onClick={goToNext} disabled={currentIndex === questions.length - 1}>
            Next
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
