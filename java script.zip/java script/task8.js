// 8. Print numbers from 1 to 10 using a for loop.


for (let i = 1; i <= 10; i++) {
  console.log(i);
}
 
