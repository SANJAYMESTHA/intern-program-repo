//5. Create a simple calculator that performs +, -, *, / based on user input.
const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});

async function calculate() {
    const num1 = parseFloat(await getInput('Enter first number: '));
    const operator = await getInput('Enter operator (+, -, *, /): ');
    const num2 = parseFloat(await getInput('Enter second number: '));
    
    if (isNaN(num1) || isNaN(num2)) {
        console.log('Please enter valid numbers');
    } else {
        let result;
        switch (operator) {
            case '+': result = num1 + num2; break;
            case '-': result = num1 - num2; break;
            case '*': result = num1 * num2; break;
            case '/': result = num1 / num2; break;
            default: result = 'Invalid operator';
        }
        console.log(`Result: ${result}`);
    }
    readline.close();
}

function getInput(question) {
    return new Promise(resolve => {
        readline.question(question, answer => resolve(answer));
    });
}

calculate();