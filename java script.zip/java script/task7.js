// 7. Write a program to determine if a person is eligible to vote (age >= 18).

const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Enter your age: ", (input) => {
    const age = parseInt(input);

    if (isNaN(age) || age < 0) {
        console.log("Please enter a valid non-negative age.");
    } else {
        if (age >= 18) {
            console.log("You are eligible to vote.");
        } else {
            console.log("You are not eligible to vote.");
        }
    }

    rl.close();
});
