// 9. Print the sum of first n natural numbers using a loop.

const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Enter a positive integer: ", (input) => {
    const n = parseInt(input);

    if (isNaN(n) || n <= 0) {
        console.log("Please enter a valid positive integer.");
        rl.close();
        return;
    }

    let sum = 0;
    for (let i = 1; i <= n; i++) {
        sum += i;
    }

    console.log(`The sum of first ${n} natural numbers is: ${sum}`);
    rl.close();
});
