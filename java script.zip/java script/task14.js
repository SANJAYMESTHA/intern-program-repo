//14. Find the sum of digits of a number using a while loop.
let number = 1234; 
let sum = 0;

while (number > 0) {
  let digit = number % 10;       
  sum += digit;                  
  number = Math.floor(number / 10); 
}

console.log("Sum of digits:", sum);