// 1. Write a program to check whether a given number is even or odd.

const readline = require("readline");

// Create interface for input and output
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Ask the user to enter a number
rl.question("Enter a number: ", function (input) {
    const number = parseInt(input);

    if (isNaN(number)) {
        console.log("Please enter a valid number.");
    } else {
        if (number % 2 === 0) {
            console.log(`${number} is even.`);
        } else {
            console.log(`${number} is odd.`);
        }
    }

    rl.close();
});
