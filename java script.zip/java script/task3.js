// 3. Write a program to check whether a given year is a leap year.

const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Enter a year: ", function (input) {
    const year = parseInt(input);

    if (isNaN(year) || year <= 0) {
        console.log("Please enter a valid positive year.");
    } else {
        if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
            console.log(`${year} is a leap year.`);
        } else {
            console.log(`${year} is not a leap year.`);
        }
    }

    rl.close();
});
