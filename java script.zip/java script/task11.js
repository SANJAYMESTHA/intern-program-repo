// 11. Reverse a number using a while loop.

const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Enter a number to reverse: ", (input) => {
    let num = parseInt(input);

    if (isNaN(num)) {
        console.log("Please enter a valid number.");
        rl.close();
        return;
    }

    let reversed = 0;

    while (num !== 0) {
        let digit = num % 10;
        reversed = reversed * 10 + digit;
        num = Math.floor(num / 10);
    }

    console.log(`Reversed number: ${reversed}`);
    rl.close();
});
