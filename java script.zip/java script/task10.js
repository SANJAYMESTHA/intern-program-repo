// 10. Print the multiplication table of a number entered by the user.

const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Enter a number to print its multiplication table: ", (input) => {
    const number = parseInt(input);

    if (isNaN(number)) {
        console.log("Please enter a valid number.");
    } else {
        console.log(`Multiplication table of ${number}:`);
        for (let i = 1; i <= 10; i++) {
            console.log(`${number} x ${i} = ${number * i}`);
        }
    }

    rl.close();
});
