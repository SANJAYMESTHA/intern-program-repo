// 2. Create a grading system using conditional statements for marks entered by the user.

const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Enter your marks (0 - 100): ", function (input) {
    const marks = parseFloat(input);

    if (isNaN(marks) || marks < 0 || marks > 100) {
        console.log("Please enter valid marks between 0 and 100.");
    } else {
        let grade;

        if (marks >= 90) {
            grade = "A+";
        } else if (marks >= 80) {
            grade = "A";
        } else if (marks >= 70) {
            grade = "B";
        } else if (marks >= 60) {
            grade = "C";
        } else if (marks >= 50) {
            grade = "D";
        } else {
            grade = "F (Fail)";
        }

        console.log(`You scored ${marks}. Your grade is: ${grade}`);
    }

    rl.close();
});
