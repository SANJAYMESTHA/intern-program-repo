// 12. Print all even numbers from 1 to 20 using a for loop.

for (let i = 1; i <= 20; i++) {
  if (i % 2 === 0) {
    console.log(i);
  }
}


